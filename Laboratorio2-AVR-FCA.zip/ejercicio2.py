"""

Laboratorio # 2.2: Ejercicio 2

Integrantes:

Armendáriz Viegas Rodrigo (AVR)
Flores Callejas Arturo (FCA)

Nombre del programa : ejercicio2.py

"""

# ----- sección de bibliotecas .
from scipy import optimize as opt #Importamos el módulo de optimización
# -----
c = [12, 50, 25, 18] #Establecemos los coeficientes de la función a minimizar
A_ub = [[-2,-1, -8, -4], [-1, -1, -4.8, -4], [-4, -3, -4, -3]]
b_ub = [-20, -15, -15]

res = opt.linprog(c , A_ub, b_ub, bounds=(0,None), method='simplex')

print('Costo mínimo de la dieta:', res.fun, '\n')

print('Raciones optimas por dieta: ') #Mostramos en pantalla la solución solicitada
print("- Pan:", res.x[0])
print("- Carne:", res.x[1])
print("- Vegetales:", res.x[2])
print("- Papas:", res.x[3])
