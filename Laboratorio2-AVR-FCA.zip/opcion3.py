"""

Laboratorio # 2.3.2: Ejercicio 3, Opción 3

Integrantes:

Armendáriz Viegas Rodrigo (AVR)
Flores Callejas Arturo (FCA)

Nombre del programa : opcion3.py

"""

# ----- sección de bibliotecas .
from pulp import *
# -----
v={"MAH":75, "PBA": 30, "MTM":80, "MSO":0, "CCH":80, "MNA": 75, "MRE": 50, "MAM": 70, "MFM": 70, "MNC": 17, "LPI": 0}
w={"MAH":4.8, "PBA": 4.8, "MTM":4.8, "MSO":4.7, "CCH":4.8, "MNA": 4.8, "MRE": 4.7, "MAM": 4.6, "MFM": 4.6, "MNC": 4.7, "LPI": 4.3}
costo=0
limite=280
lugares=list(sorted(v.keys()))

problema = LpProblem('Turismo', LpMaximize)

x=LpVariable.dicts('x', lugares, lowBound=0, upBound=1, cat=LpInteger)

problema+= sum(w[i]*x[i]for i in lugares), 'Función objetivo'

problema += sum(v[i]*x[i]for i in lugares) <= limite , 'Presupuesto máximo'

problema += x["MNA"]==1, 'Visita obligatoria al Museo Nacional de Antropología e historia'

problema += x["PBA"]==1, 'Visita obligatoria al Palacio de Bellas Artes'
#el resto es análogo a las opciones anteriores
print(problema, '\n')
problema.solve() 

print(f'Calificación máxima: {value(problema.objective)} estrellas')

print('Lugares por visitar')
for i in v: 
  if x[i].varValue != 0: 
    print("- {}".format(i))
    costo+=v[i]
print("Costo total: $" + str(costo) + ".00MXN")


"""

Laboratorio # 2.3.3.0: Ejercicio 3, Opción 3, Ruta Óptima

Integrantes:

Armendáriz Viegas Rodrigo (AVR)
Flores Callejas Arturo (FCA)


"""

# ----- sección de bibliotecas .
import numpy as np
import pandas as pd
# -----
distanciasTotales=pd.DataFrame([[0.0, 6.0, 7.7, 6.3, 3.3, 5.5, 4.1, 3.3, 5.2, 7.2, 2.5], [6.0, 0.0, 1.9, 8.0, 5.4, 1.5, 2.4, 5.4, 1.1, 2.3, 8.9], [7.7, 1.9, 0.0, 10.2, 7.1, 2.2, 3.8, 7.1, 2.6, 0.4, 13.7], [6.3, 8.0, 10.2, 0.0, 5.7, 9.2, 7.0, 5.7, 8.4, 10.1, 4.5], [3.3, 5.4, 7.1, 5.7, 0.0, 5.6, 5.4, 0.1, 4.8, 6.7, 2.3], [5.5, 1.5, 2.2, 9.2, 5.6, 0.0, 1.7, 4.9, 0.45, 1.6, 8.1], [4.1, 2.4, 3.8, 7.0, 5.4, 1.7, 0.0, 3.4, 1.9, 3.8, 6.7], [3.3, 5.4, 7.1, 5.7, 0.1, 4.9, 3.4, 0.0, 4.8, 6.7, 2.5], [5.2, 1.1, 2.6, 8.4, 4.8, 0.45, 1.9, 4.8, 0.0, 2.1, 7.8], [7.2, 2.3, 0.4, 10.1, 6.7, 1.6, 3.8, 6.7, 2.1, 0.0, 13.3], [2.5, 8.9, 13.7, 4.5, 2.3, 8.1, 6.7, 2.5, 7.8, 13.3, 0.0]], index=("MAH", "PBA", "MTM", "MSO", "CCH", "MNA", "MRE", "MAM", "MFM", "MNC", "LPI"), columns=("MAH", "PBA", "MTM", "MSO", "CCH", "MNA", "MRE", "MAM", "MFM", "MNC", "LPI"))

distancias=distanciasTotales.loc[["MAH", "PBA", "MSO", "CCH", "MNA", "MNC", "LPI"],["MAH", "PBA", "MSO", "CCH", "MNA", "MNC", "LPI"]].values
#puesto que son los mismos lúgares, el código es casi idéntico al de la Opción 1 (solo cambia el nombre del problema)
ruta=LpProblem("Ruta_3", LpMinimize)

n_point=len(distancias[0])

x=LpVariable.dicts('x', ((i, j) for i in range(n_point) for j in range(n_point)), lowBound=0, upBound=1, cat='Binary')

u = LpVariable.dicts('u', (i for i in range(n_point)), lowBound=1, upBound=n_point, cat='Integer')

ruta += lpSum(distancias[i][j] * x[i, j] for i in range(n_point) for j in range(n_point))


for i in range(n_point):
    ruta += x[i, i] == 0

for i in range(n_point):
    ruta+= lpSum(x[i, j] for j in range(n_point)) == 1
    ruta+= lpSum(x[j, i] for j in range(n_point)) == 1

for i in range(n_point):
    for j in range(n_point):
        if i != j and (i != 0 and j != 0):
            ruta+= u[i] - u[j] <= n_point * (1 - x[i, j]) - 1

ruta.solve()
print("La longitud de la ruta más corta es " + str(np.round(value(ruta.objective), 1)) + "km")
