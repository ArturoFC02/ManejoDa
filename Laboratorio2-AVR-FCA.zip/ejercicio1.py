"""

Laboratorio # 2.1: Ejercicio 1

Integrantes:

Armendáriz Viegas Rodrigo (AVR)
Flores Callejas Arturo (FCA)

Nombre del programa : ejercicio1.py

"""

# ----- sección de bibliotecas .
import numpy as np
import matplotlib.pyplot as plt
# -----
x1=np.arange(0, 10, 0.001) 
x2=np.arange(0, 10, 0.001)
#definimos los rangos en los que graficaremos las variables
r1=2-(1/2)*x1
r2=6-2*x1
r3=(1/2)*(1+x1)
r4=0*r2
r5=0*x1 #obtenemos los arreglos correspondientes a cada restricción para graficarlas

s=[0 for i in range(len(x1))]
for i in range(len(x1)):
  s[i]=max(r1[i], r2[i], r3[i])
  #definimos el arreglo que utilizaremos para llenar el área factible
  #debido a que todas las restricciones son de mayor o igual, tomamos su máximo en cada punto, pues este contiene a las demás

plt.figure(figsize=(6, 6))
plt.plot(x1, r1, label=r"$x_2 \leq 2- \frac{1}{2}x_1$")
plt.plot(x1, r2, label=r"$x_2  \geq  6-2x_1$")
plt.plot(x1, r3, label=r"$x_2  \geq  \frac{1}{2} (1+x_1)$")
plt.plot(x1, r4, label=r"$x_2 \geq 0$")
plt.plot(r5, x2, label=r"$x_1 \geq 0$") #graficamos las rectas de las restricciones

plt.fill_between(x2, s, 10, where=[s[i]>=0 for i in range(len(s))], label="Área de factibilidad")
#llenamos el área de factibilidad hasta 10 (aunque es infinita)
plt.axis([-1,7,-1,7])
#ajustamos los ejes
plt.grid(True)
plt.legend()
plt.show()